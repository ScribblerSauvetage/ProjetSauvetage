/*
  Blank Simple Project.c
  http://learn.parallax.com/propeller-c-tutorials 
*/
#include "algo.h"
#include "robot.h"

int main()                                    // Main function
{
  // Add startup code here.
  int grille[Taille_grille][Taille_grille];
  
  //***********init grille************//
  for(int i=0; i<Taille_grille; i++)
  {
    for(int j=0; j<Taille_grille; j++)
    {
      grille[i][j] = 0;     //0 : pas d'obstacle, 1 : obstacle
    }
  }
  //*******************************//  
        
  s3_setup();
  pause(100);
  
  simpleterm_reopen(31,30,0,9600);
  
  Robot robot;
  robot.posX = 15;
  robot.posY = 15;
  robot.orientation = 90;
  
  //*********************
  
  robot.posX = 5;
  robot.posY = 5;
  send_pos_robot();  
  *********************/
  return 0;
}
