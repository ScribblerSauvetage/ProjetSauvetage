/*
  Blank Simple Project.c
  http://learn.parallax.com/propeller-c-tutorials 
*/
#include "s3.h"
//#include "simpletext.h"
#define M_PI 3.14159265358979323846f
//#include <math.h>
#include "vl53l1x.h"


#define A_VERIFIER 0
#define PAS_OBSTACLE 1
#define OBSTACLE 2 

#define TAILLE_GRILLE 31
#define NB_SOUS_CASES 40
#define TAILLE_CASE_MM 200

#define EXPLORATION 1
#define CONTROL 0

#define UP  1
#define DOWN  2
#define RIGHT 3
#define LEFT  4

/**********************************  ROBOT    ************************************/

struct Robot{
  int posX;
  int posY;
  int vitesse; //vitesse entre 0 et 15
  int orientation;
};  
typedef struct Robot Robot;

struct Case{
  //int sous_cases[NB_SOUS_CASES/2][NB_SOUS_CASES/2];
  int status;

};
typedef struct Case Case;

unsigned char grille[TAILLE_GRILLE][TAILLE_GRILLE];

/****************************Table TRIGO*************************************/
float Trigo[][2] = {
  //{cos, sin}
  {1.f, 0.f},
  {0.996195f, 0.087156f}, //5°
  {0.984808f, 0.173648f}, //10°
  {0.965926f, 0.258819f}, //15°
  {0.939693f, 0.342020f}, //20°
  {0.906308f, 0.422618f}, //25°
  {0.866025f, 0.5f}, //30°
  {0.819152f, 0.573576f}, //35°
  {0.766044f, 0.642788f}, //40°
  {0.707170f, 0.707170f}, //45°
  {0.642788f, 0.766044f}, //50°
  {0.573576f, 0.819152f}, //55°
  {0.5f, 0.866025f}, //60°
  {0.422618f, 0.906308f}, //65°
  {0.342020f, 0.939693f}, //70°
  {0.258819f, 0.965926f}, //75°
  {0.173648f, 0.984808f}, //80°
  {0.087156f, 0.996195f}, //85°
  {0.f, 1.f} //90°
};

float _cos(int angle_deg)
{
  if(angle_deg>=0 && angle_deg<90)
  {
    return Trigo[angle_deg/5][0];
  }
  else if(angle_deg>=90 && angle_deg<180)
  {
    return (- Trigo[(180-angle_deg)/5][0]);
  }
  else if(angle_deg>=180 && angle_deg<270)
  {
    return (- Trigo[(angle_deg-180)/5][0]);
  }
  else if(angle_deg>=270 && angle_deg<360)
  {
    return Trigo[(360-angle_deg)/5][0];
  }
  else 
  {
    print("pas cense arriver la\n");
    return 2.f;
  }               
}  

float _sin(int angle_deg)
{
  if(angle_deg>=0 && angle_deg<90)
  {
    return Trigo[angle_deg/5][1];
  }
  else if(angle_deg>=90 && angle_deg<180)
  {
    return Trigo[(180-angle_deg)/5][1];
  }
  else if(angle_deg>=180 && angle_deg<270)
  {
    return (- Trigo[(angle_deg-180)/5][1]);
  }
  else if(angle_deg>=270 && angle_deg<360)
  {
    return (-Trigo[(360-angle_deg)/5][1]);
  }
  else 
  {
    print("pas cense arriver la\n");
    return 2.f;
  }
}

int arrondi_sup(float val)
{ 
  int   inttemp    = (int) (val);
   
  // Arrondi Superieur
  if ((val - inttemp) > 0)
  {
      return inttemp+1;
  }
  // Arrondi Inferieur
  else
  {
      return inttemp;
  }
}    

/************************************    CALIBRAGE CAPTEUR   ***********************************/
int getDist_calibrate()
{
  int sum=0;
  int mes;
  for(int i=0;  i<10; i++)
  {
    mes = getDistance();
    if(mes > 100)
    {
      sum+=mes;
    }
    pause(50);     
  }
  sum/=10;
  return sum; 
}  
/***********************************************************************************************/
/***************************   MOUVEMENT ******************************************/
int orientTo(Robot robot, int angleVoulu){
  /*int delta;
  int temp2 = robot.orientation;
  int temp = abs(temp2 - angleVoulu);
  if(temp <= 180)
  {
    if(temp2<angleVoulu) delta = angleVoulu - temp2;
    else delta = - temp2 + angleVoulu;
  }
  else
  {
    if (robot.orientation < 180)  delta = - temp2 - 360 + angleVoulu;
    else delta = 360 - temp2 + angleVoulu;
  }  */      
     
  angleVoulu = angleVoulu%360;
  if(angleVoulu==0)angleVoulu=360;     
  int delta = abs(angleVoulu - robot.orientation);
  int angle = 180 - abs(delta - 180); 
  if(angleVoulu < robot.orientation)
  {
    angle*=-1;
  }
  if(delta > 180)
  {
    angle*=-1;
  }        
  scribbler_turn_by_deg(angle);
  scribbler_wait_stop();
  if(angleVoulu == 360) return 0;
  else return angleVoulu;
}

// 180 - abs(abs(10 - 90) - 180) = 80 
// 180 - abs(abs(10 - 270) - 180) = 100 

int turn_right(Robot robot)
{
  scribbler_turn_by_deg(-90);
  scribbler_wait_stop();
  robot.orientation-= 90;
  if(robot.orientation<0) { robot.orientation+= 360; }
  robot.orientation = robot.orientation%360;
  return robot.orientation;
}

int turn_left(Robot robot)
{
  scribbler_turn_by_deg(90);
  scribbler_wait_stop();
  robot.orientation+= 90;
  robot.orientation = robot.orientation%360;
  return robot.orientation;
} 

Robot move_1_case(Robot robot) // fais avancer le robot d'une case
{
  scribbler_go_forward(400);
  if(robot.orientation == 90)
    {
      robot.posY+=1;
    }
  else if(robot.orientation == 0)
    {
      robot.posX+=1;
    }
  else if(robot.orientation == 180)
    {
      robot.posX-=1;
    }
  else
    {
      robot.posY-=1;
    }
    return robot;
}
/**********************************************************************************/

/************************************    ALGO   ***********************************/
/*void algo_v1(Robot *robot,  int **grille){
	
}
*/
int automate_control()
{
    int commande;
    int vitesse;
    int rx_check;
    commande = 0;
    vitesse = 0;
    commande = getChar();
    vitesse = getChar() - '0'+1;
    if(commande == 'z'){
      scribbler_wheels_now(51*vitesse,51*vitesse,0);
    }else if( commande == 'q'){
      scribbler_wheels_now(-51*vitesse,51*vitesse,0);
    }else if( commande == 's'){
      scribbler_wheels_now(-51*vitesse,-51*vitesse,0);
    }else if( commande == 'd'){
      scribbler_wheels_now(51*vitesse,-51*vitesse,0);
    }else if( commande == 'x'){     
      scribbler_wheels_now(0,0,0);
    }else if( commande == 'w'){
      scribbler_wheels_now(0,0,0);
      return 0;
    }            
    pause(500);
    return 1;
} 
 
void compute(int x, int y, unsigned char _status, Robot robot)
{
  int coord_x, coord_y;
  coord_x = ((x-100)/200)+1+robot.posX;
  coord_y = ((y-100)/200)+1+robot.posY;
  if(grille[coord_y][coord_x] == A_VERIFIER)
  {
     grille[coord_y][coord_x] = _status;
     if(_status== OBSTACLE) print("obs:%3d,%3d", coord_x, coord_y);
     //if(_status== PAS_OBSTACLE) print("vid:%3d,%3d", coord_x, coord_y );    
  }      
}


Robot  detection360deg(Robot robot){
  int distance;
  const int PAS=5;
  int angle;
  scribbler_set_speed(2);
  //print("Obstacles : \n");
  robot.orientation = orientTo(robot, 360);
  /*distance = getDist_calibrate();
  updateGridWithDetection(robot, distance);
  print("pts:%4d,%3d",distance, robot.orientation);
  robot.orientation = orientTo(robot, 5);*/
  for(angle=0;  angle <= 360; angle+=PAS){
    //pause(200);
    distance = getDist_calibrate();
    updateGridWithDetection(robot, distance);
    print("pts:%4d,%3d",distance, robot.orientation);
    robot.orientation = orientTo(robot, (robot.orientation)+PAS);
  }
  return robot;
  //robot.orientation = orientTo(robot, (robot.orientation)+PAS);
  //print("ori=%d\n",0);
}

void updateGridWithDetection(Robot robot, int distance){ // ATTENTION, les coords des sous point sont relative au robot et pas à l'origine de la grille
  float x_point=0, y_point=0, nb_points, x_sousPnt, y_sousPnt; 
  //float coef_a, x_intervalle;// un sous-point à un intervalle de x mm.

  x_point = _cos(robot.orientation)*(distance); // Valeur en millimetre
  y_point = _sin(robot.orientation)*(distance);
  compute(x_point, y_point, OBSTACLE, robot);
  
  for (int i=100; i<distance-50; i+=50)
  {
     x_sousPnt = _cos(robot.orientation)*i;
     y_sousPnt = _sin(robot.orientation)*i;
     compute(x_sousPnt, y_sousPnt, PAS_OBSTACLE, robot); 
  }
}  

char findConnex(Robot robot, int caseY, int caseX, int* coord)
{
  int distmin, dist;
  unsigned char direction;
  distmin = 20000000;
  if(grille[caseY+1][caseX] == PAS_OBSTACLE)
  {
    dist = (caseX - robot.posX)*(caseX - robot.posX) + ((caseY+1) - robot.posY)*((caseY+1) - robot.posY);
    if(dist<distmin)
    { 
      distmin = dist;
      direction = DOWN;
      coord[0] = caseY+1; coord[1] = caseX;
    }                                
  }
  if(grille[caseY-1][caseX] ==  PAS_OBSTACLE)
  {
    dist = (caseX - robot.posX)*(caseX - robot.posX) + ((caseY-1) - robot.posY)*((caseY-1) - robot.posY);
    if(dist<distmin)
    {
      distmin = dist;
      direction = UP; 
      coord[0] = caseY-1; coord[1] = caseX;
    }      
  }
  if(grille[caseY][caseX+1] ==  PAS_OBSTACLE)
  {
    dist = ((caseX+1) - robot.posX)*((caseX+1) - robot.posX) + (caseY - robot.posY)*(caseY - robot.posY);
    if(dist<distmin)
    {
      distmin = dist;
      direction = LEFT; 
      coord[0] = caseY; coord[1] = caseX+1;
    }
  }
  if(grille[caseY][caseX-1] ==  PAS_OBSTACLE)
  {
    dist = ((caseX-1) - robot.posX)*((caseX-1) - robot.posX) + (caseY - robot.posY)*(caseY - robot.posY);
    if(dist<distmin)
    {
      distmin = dist;
      direction = RIGHT; 
      coord[0] = caseY; coord[1] = caseX-1;
    }
  }
  return direction;            
}  

char search(int y, int x)
{
  if((grille[y+1][x] == A_VERIFIER)||(grille[y-1][x] == A_VERIFIER) || (grille[y][x-1] == A_VERIFIER) || (grille[y][x+1] == A_VERIFIER)) return 1;
  else return 0;
}  

char findCaseToCheck(int *coord)
{
  for (int y=TAILLE_GRILLE-2; y>15; y--)
  {
    for(int x = 1; x<TAILLE_GRILLE-1; x++)
    {
      if((grille[y][x] == PAS_OBSTACLE) && search(y, x))
      {
        coord[0] = y;
        coord[1] = x;
        return 1;
      }        
    }
  }          
  return 0;
}    

Robot followPath(Robot robot, unsigned char* direction, int taille_tab){
  for(int i =taille_tab ; i >= 0 ; i--){
     if(direction[i]==UP){ 
      robot.orientation = orientTo(robot, 90);
      robot = move_1_case(robot);
      print("orientation : %d\n", robot.orientation);
     }else if( direction[i]==DOWN){ 
      robot.orientation = orientTo(robot, 270);
      robot = move_1_case(robot);
      print("orientation : %d\n", robot.orientation);
     }else if(direction[i]==RIGHT){ 
      robot.orientation = orientTo(robot, 360);
      robot = move_1_case(robot);
      print("orientation : %d\n", robot.orientation);
     }else{ 
      robot.orientation = orientTo(robot, 180);
      print("orientation : %d\n", robot.orientation);
      robot = move_1_case(robot);
     }
  }
  return robot;     
}
char findPathTo(Robot robot)
{
  int coord[2];
  unsigned char direction[20], idx_direction=0;
  
  if(!findCaseToCheck(coord)){
    return 0;  
  }
  print("cib:%3d,%3d", coord[1], coord[0]); 
  do
  {
    direction[idx_direction] = findConnex(robot, coord[0], coord[1], coord);
    idx_direction++;
    print("cib:%3d,%3d", coord[1], coord[0]);
    pause(1000);
  }while(coord[0]!=robot.posY && coord[1]!=robot.posX);
  print("Follow\n");
  for(unsigned char i=0 ; i < idx_direction ; i++){
    print("%d: %d",(int)i,(int)direction[i]);
  }    
  followPath(robot, direction, idx_direction);  
    
  return 1;
} 

/*void updateGrid(int dist, Robot robot)
{
  //float x_point = cosf(robot.orientation*M_PI/180.f)*dist; // Valeur en millimetre
  print("x_point : %.2f\n", cosf(robot.orientation*M_PI/180.f)*dist);
  //float y_point = sinf(robot.orientation*M_PI/180.f)*dist;
  print("y_point : %.2f\n", sinf(robot.orientation*M_PI/180.f)*dist);
  
} */                              

/**********************************************************************************/




int main()                                    // Main function
{
  Robot robot;
  s3_setup();
  pause(1000);
  int automate = CONTROL;
   
  //print("Setup\n");
  //simpleterm_reopen(31,30,0,9600);
  //Robot robot;
  /*grille=malloc(sizeof(Case*)*TAILLE_GRILLE);
  for(int i=0; i<TAILLE_GRILLE; i++) grille[i]=malloc(sizeof(Case)*TAILLE_GRILLE);*/
  //print("init grille\n");
  //***********init grille************//
  for(int i=0; i<31; i++)
  {
    for(int j=0; j<31; j++)
    {
      grille[i][j] = 0;     
    }
  } 
  
  robot.orientation = 90;
  scribbler_heading_is_deg(robot.orientation);
  simpleterm_reopen(31,30,0,9600);// 31 30
  
  while(automate_control()) {}   

  init_VL53L1X(1);
  
  robot.posX = 15;
  robot.posY = 15;
  
  int distance;

  //print("rob:%3d,%3d", robot.posX, robot.posY);
  //updateGrid(distance, robot);
  
  //turn_right(&robot);
  //orientTo(&robot, 0);
  //detection360deg(&robot,grille);
  //updateGridWithDetection(robot, grille, distance);
  
  //int orientation = 90;
  
  int case_x, case_y;
  float x_ss_point, y_ss_point;
  const int PAS=10;
  int angle;
  
  distance = getDist_calibrate();
  //print("distance : %d \n", distance);
  robot = detection360deg(robot);
  int coord[2];
  scribbler_set_speed(8);
  //char zbeb = findPathTo(robot);
  
//  print("cib:%3d,%3d", coord[1], coord[0]);
  
  //print("Obstacles : \n");
  /*for(int y=0; y<31; y++)
  {
    for(int x=0; x<31; x++)
    {
      if(grille[y][x]== OBSTACLE) print("coord_x : %d, coord_y : %d \n ", y, x);     
    }
  }
  
  /**************TEST FONCTIONS***************/
  /*robot.orientation = orientTo(robot, 50);
  printf("orientation %d \n", robot.orientation);
  
  robot.orientation = turn_right(robot);
  printf("orientation %d \n", robot.orientation);
   
  robot.orientation = turn_left(robot);
  printf("orientation %d \n", robot.orientation);
  
  distance = getDist_calibrate();
  print("distance : %d \n", distance);
  
  robot = move_1_case(robot);
  printf("coord y : %d \n", robot.posY);
  
  int x_point, y_point;
  x_point = _cos(robot.orientation)*(distance - TAILLE_CASE_MM/2);
  y_point = _sin(robot.orientation)*(distance - TAILLE_CASE_MM/2);
  compute(x_point, y_point, 2, robot);
  */
  /*****************************************/
 /* print("angle : 80 cos : %f \n", _sin(80));
  print("angle : 135 cos : %f \n", _sin(135));
  print("angle : 225 cos : %f \n", _sin(225));
  print("angle : 315 cos : %f \n", _sin(315));
  
 /* 
  
  /*********************
  
  robot.posX = 5;
  robot.posY = 5;
  send_pos_robot();  
  *********************/
  /*for(int i=0; i<TAILLE_GRILLE; i++) free(grille[i]);
  free(grille);*/
  return 0;
}
