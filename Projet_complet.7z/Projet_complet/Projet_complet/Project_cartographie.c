/*
  Blank Simple Project.c
  http://learn.parallax.com/propeller-c-tutorials 
*/
#include "s3.h"
#include "simpletext.h"
#define M_PI 3.14159265358979323846f
//#include <math.h>
#include "vl53l1x.h"


#define A_VERFIER 0
#define PAS_OBSTACLE 1
#define OBSTACLE 2 

#define TAILLE_GRILLE 31
#define NB_SOUS_CASES 40
#define TAILLE_CASE_MM 200

#define EXPLORATION 1
#define CONTROL 0

/**********************************  ROBOT    ************************************/

struct Robot{
  int posX;
  int posY;
  int vitesse; //vitesse entre 0 et 15
  int orientation;
};  
typedef struct Robot Robot;

struct Case{
  //int sous_cases[NB_SOUS_CASES/2][NB_SOUS_CASES/2];
  int status;

};
typedef struct Case Case;

unsigned char grille[TAILLE_GRILLE][TAILLE_GRILLE];

/****************************Table TRIGO*************************************/
float Trigo[][2] = {
  //{cos, sin}
  {1.f, 0.f},
  {0.996195f, 0.087156f}, //5°
  {0.984808f, 0.173648f}, //10°
  {0.965926f, 0.258819f}, //15°
  {0.939693f, 0.342020f}, //20°
  {0.906308f, 0.422618f}, //25°
  {0.866025f, 0.5f}, //30°
  {0.819152f, 0.573576f}, //35°
  {0.766044f, 0.642788f}, //40°
  {0.707170f, 0.707170f}, //45°
  {0.642788f, 0.766044f}, //50°
  {0.573576f, 0.819152f}, //55°
  {0.5f, 0.866025f}, //60°
  {0.422618f, 0.906308f}, //65°
  {0.342020f, 0.939693f}, //70°
  {0.258819f, 0.965926f}, //75°
  {0.173648f, 0.984808f}, //80°
  {0.087156f, 0.996195f}, //85°
  {0.f, 1.f} //90°
};

float _cos(int angle_deg)
{
  if(angle_deg>=0 && angle_deg<90)
  {
    return Trigo[angle_deg/5][0];
  }
  else if(angle_deg>=90 && angle_deg<180)
  {
    return (- Trigo[(180-angle_deg)/5][0]);
  }
  else if(angle_deg>=180 && angle_deg<270)
  {
    return (- Trigo[(angle_deg-180)/5][0]);
  }
  else if(angle_deg>=270 && angle_deg<360)
  {
    return Trigo[(360-angle_deg)/5][0];
  }
  else 
  {
    print("pas cense arriver la\n");
    return 2.f;
  }               
}  

float _sin(int angle_deg)
{
  if(angle_deg>=0 && angle_deg<90)
  {
    return Trigo[angle_deg/5][1];
  }
  else if(angle_deg>=90 && angle_deg<180)
  {
    return Trigo[(180-angle_deg)/5][1];
  }
  else if(angle_deg>=180 && angle_deg<270)
  {
    return (- Trigo[(angle_deg-180)/5][1]);
  }
  else if(angle_deg>=270 && angle_deg<360)
  {
    return (-Trigo[(360-angle_deg)/5][1]);
  }
  else 
  {
    print("pas cense arriver la\n");
    return 2.f;
  }
}

int arrondi_sup(float val)
{ 
  int   inttemp    = (int) (val);
   
  // Arrondi Superieur
  if ((val - inttemp) > 0)
  {
      return inttemp+1;
  }
  // Arrondi Inferieur
  else
  {
      return inttemp;
  }
}    

/************************************    CALIBRAGE CAPTEUR   ***********************************/
int getDist_calibrate()
{
  int sum=0;
  int mes;
  for(int i=0;  i<10; i++)
  {
    mes = getDistance();
    if(mes > 100)
    {
      sum+=mes;
    }
    pause(50);     
  }
  sum/=10;
  return sum; 
}  
/***********************************************************************************************/
/***************************   MOUVEMENT ******************************************/
int orientTo(Robot robot, int angleVoulu){
  angleVoulu = angleVoulu%360;
  if(angleVoulu==0)angleVoulu=360;     
  int delta = abs(angleVoulu - robot.orientation);
  int angle = 180 - abs(delta - 180); 
  if(delta> 180)angle*=-1;
  scribbler_turn_by_deg(angle);
  scribbler_wait_stop();
  
  return angleVoulu;
}

// 180 - abs(abs(10 - 90) - 180) = 80 
// 180 - abs(abs(10 - 270) - 180) = 100 

int turn_right(Robot robot)
{
  scribbler_turn_by_deg(-90);
  scribbler_wait_stop();
  robot.orientation-= 90;
  if(robot.orientation<0) { robot.orientation+= 360; }
  robot.orientation = robot.orientation%360;
  return robot.orientation;
}

int turn_left(Robot robot)
{
  scribbler_turn_by_deg(90);
  scribbler_wait_stop();
  robot.orientation+= 90;
  robot.orientation = robot.orientation%360;
  return robot.orientation;
} 

Robot move_1_case(Robot robot) // fais avancer le robot d'une case
{
  scribbler_go_forward(400);
  if(robot.orientation == 90)
    {
      robot.posY+=1;
    }
  else if(robot.orientation == 0)
    {
      robot.posX+=1;
    }
  else if(robot.orientation == 180)
    {
      robot.posX-=1;
    }
  else
    {
      robot.posY-=1;
    }
    return robot;
}
/**********************************************************************************/

/************************************    ALGO   ***********************************/
/*void algo_v1(Robot *robot,  int **grille){
	
}
*/
int automate_control()
{
    int commande;
    int vitesse;
    int rx_check;
    commande = 0;
    vitesse = 0;
    commande = getChar();
    vitesse = getChar() - '0'+1;
    if(commande == 'z'){
      scribbler_wheels_now(51*vitesse,51*vitesse,0);
    }else if( commande == 'q'){
      scribbler_wheels_now(-51*vitesse,51*vitesse,0);
    }else if( commande == 's'){
      scribbler_wheels_now(-51*vitesse,-51*vitesse,0);
    }else if( commande == 'd'){
      scribbler_wheels_now(51*vitesse,-51*vitesse,0);
    }else if( commande == 'x'){     
      scribbler_wheels_now(0,0,0);
    }else if( commande == 'w'){
      scribbler_wheels_now(0,0,0);
      return 0;
    }            
    pause(500);
    return 1;
} 
 
void compute(int x, int y, unsigned char _status, Robot robot)
{
  int coord_x, coord_y;
  coord_x = arrondi_sup((robot.posX*TAILLE_CASE_MM +x)/(float)TAILLE_CASE_MM);
  coord_y = arrondi_sup((robot.posY*TAILLE_CASE_MM+y)/(float)TAILLE_CASE_MM);
  if(grille[coord_y][coord_x] == A_VERFIER)
  {
     grille[coord_y][coord_x] = _status;
     if(_status== OBSTACLE) print("obs:%3d,%3d", coord_x, coord_y);
     if(_status== PAS_OBSTACLE) print("vid:%3d,%3d", coord_x, coord_y );    
  }      
}


void  detection360deg(Robot robot){
  int distance;
  const int PAS=5;
  int angle;
  scribbler_set_speed(3);
  //print("Obstacles : \n");
  for(angle=0;  angle < 90; angle+=PAS){
    //pause(200);
    distance = getDist_calibrate();
    updateGridWithDetection(robot, distance);
    robot.orientation = orientTo(robot, (robot.orientation)+PAS);
    print("ang:%3d", robot.orientation);
  }
  robot.orientation = orientTo(robot, (robot.orientation)+PAS);
  //print("ori=%d\n",0);
}

void updateGridWithDetection(Robot robot, int distance){ // ATTENTION, les coords des sous point sont relative au robot et pas à l'origine de la grille
  float x_point=0, y_point=0, nb_points, x_sousPnt, y_sousPnt; 
  //float coef_a, x_intervalle;// un sous-point à un intervalle de x mm.

  x_point = _cos(robot.orientation)*(distance - TAILLE_CASE_MM/2); // Valeur en millimetre
  y_point = _sin(robot.orientation)*(distance - TAILLE_CASE_MM/2);
  compute(x_point, y_point, OBSTACLE, robot);
  
  for (int i=100; i<distance; i+=50)
  {
     x_sousPnt = _cos(robot.orientation)*i;
     y_sousPnt = _sin(robot.orientation)*i;
     compute(x_sousPnt, y_sousPnt, PAS_OBSTACLE, robot); 
  }
}  

  /*coef_a = y_point/(float)x_point;// On calcul le coef de la droite
  nb_points = distance/intervalle;
  if(x_point==0){// a traiter
    
  }else{
    x_intervalle = x_point/nb_point;
    for(int idx=0 ; (idx)<distance ; idx++){
      x_sousPnt = idx*x_intervalle;
      y_sousPnt = x_sousPnt*coef_a;
      // On traite le sous-point
    }
  }
  
  
  //print("x=%d, y=%d\n",x_point,y_point);
}*/

/*void updateGrid(int dist, Robot robot)
{
  //float x_point = cosf(robot.orientation*M_PI/180.f)*dist; // Valeur en millimetre
  print("x_point : %.2f\n", cosf(robot.orientation*M_PI/180.f)*dist);
  //float y_point = sinf(robot.orientation*M_PI/180.f)*dist;
  print("y_point : %.2f\n", sinf(robot.orientation*M_PI/180.f)*dist);
  
} */                              

/**********************************************************************************/




int main()                                    // Main function
{
  Robot robot;
  s3_setup();
  pause(1000);
  int automate = CONTROL;
  //print("Setup\n");
  //simpleterm_reopen(31,30,0,9600);
  //Robot robot;
  /*grille=malloc(sizeof(Case*)*TAILLE_GRILLE);
  for(int i=0; i<TAILLE_GRILLE; i++) grille[i]=malloc(sizeof(Case)*TAILLE_GRILLE);*/
  //print("init grille\n");
  //***********init grille************//
  for(int i=0; i<31; i++)
  {
    for(int j=0; j<31; j++)
    {
      grille[i][j] = 0;     
    }
  }
  //print("init grille fini\n");
  
 /* for(int i=0; i<TAILLE_GRILLE; i++)
  {
    for(int j=0; j<TAILLE_GRILLE; j++)
    {
      print("%d  ", grille[i][j]);    
    }
    print("ligne : %d \n", i);
  }*/
  //*******************************//  
   
  simpleterm_reopen(31,30,0,9600);// 31 30
  
  while(automate_control()) {}   

  init_VL53L1X(1);
  
  robot.posX = 15;
  robot.posY = 15;
  robot.orientation = 0;
  scribbler_heading_is_deg(robot.orientation);
  int distance;
  //print("rob:%3d,%3d", robot.posX, robot.posY);
  //updateGrid(distance, robot);
  
  //turn_right(&robot);
  //orientTo(&robot, 0);
  //detection360deg(&robot,grille);
  //updateGridWithDetection(robot, grille, distance);
  
  //int orientation = 90;
  
  int case_x, case_y;
  float x_ss_point, y_ss_point;
  const int PAS=10;
  int angle;
  scribbler_set_speed(6);
  distance = getDist_calibrate();
  //print("distance : %d \n", distance);
  detection360deg(robot);
  //print("Obstacles : \n");
  /*for(int y=0; y<31; y++)
  {
    for(int x=0; x<31; x++)
    {
      if(grille[y][x]== OBSTACLE) print("coord_x : %d, coord_y : %d \n ", y, x);     
    }
  }
  
  /**************TEST FONCTIONS***************/
  /*robot.orientation = orientTo(robot, 50);
  printf("orientation %d \n", robot.orientation);
  
  robot.orientation = turn_right(robot);
  printf("orientation %d \n", robot.orientation);
   
  robot.orientation = turn_left(robot);
  printf("orientation %d \n", robot.orientation);
  
  distance = getDist_calibrate();
  print("distance : %d \n", distance);
  
  robot = move_1_case(robot);
  printf("coord y : %d \n", robot.posY);
  
  int x_point, y_point;
  x_point = _cos(robot.orientation)*(distance - TAILLE_CASE_MM/2);
  y_point = _sin(robot.orientation)*(distance - TAILLE_CASE_MM/2);
  compute(x_point, y_point, 2, robot);
  */
  /*****************************************/
 /* print("angle : 80 cos : %f \n", _sin(80));
  print("angle : 135 cos : %f \n", _sin(135));
  print("angle : 225 cos : %f \n", _sin(225));
  print("angle : 315 cos : %f \n", _sin(315));
  
 /* for(angle=0;  angle < 60; angle+=PAS){
    //pause(200);
    robot.orientation = orientTo(robot, (robot.orientation)+PAS);
    //robot.orientation += PAS ;
    distance = getDist_calibrate();
    //x_point = cosf(robot.orientation*M_PI/180.f)*distance; // Valeur en millimetre
    //print("x_point : %.2f\n", x_point);
    
    
    //y_point = sinf(robot.orientation*M_PI/180.f)*distance;
    //print("y_point : %.2f\n", y_point);
       
    case_x = (robot.posX*TAILLE_CASE_MM +(int)x_point)/TAILLE_CASE_MM;
    //print("case_x : %d\n", case_x);
    case_y = (robot.posY*TAILLE_CASE_MM+(int)y_point)/TAILLE_CASE_MM;
    //print("case_y : %d\n", case_y);
    grille[case_x][case_y] = 1; 
    
    
    for (int i=0; i<distance; i+=25)
    {
       //x_ss_point = cosf(robot.orientation*M_PI/180.f)*i;
      //print("x_point : %.2f\n", x_ss_point);
       //y_ss_point = sinf(robot.orientation*M_PI/180.f)*i;
      case_x = (robot.posX*TAILLE_CASE_MM +(int)x_ss_point)/TAILLE_CASE_MM;
      //print("case_x : %.2f\n", case_x);
      case_y = (robot.posY*TAILLE_CASE_MM+(int)y_ss_point)/TAILLE_CASE_MM;
      if(!grille[case_x][case_y])grille[case_x][case_y] = 2;
    }
  }                                                                   
  
  print("obstacles :\n");
  for(int i=0; i<TAILLE_GRILLE; i++)
  {
    for(int j=0; j<TAILLE_GRILLE; j++)
    {
      if(grille[i][j] == 1) print("coord Case : %d  %d\n", i, j); ;     
    }
  }
  print("\ncases vides :\n");
  for(int i=0; i<TAILLE_GRILLE; i++)
  {
    for(int j=0; j<TAILLE_GRILLE; j++)
    {
      if(grille[i][j] == 2) print("coord Case : %d  %d\n", i, j); ;     
    }
  }
  
  /*********************
  
  robot.posX = 5;
  robot.posY = 5;
  send_pos_robot();  
  *********************/
  /*for(int i=0; i<TAILLE_GRILLE; i++) free(grille[i]);
  free(grille);*/
  return 0;
}
