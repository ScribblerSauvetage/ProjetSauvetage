#ifndef _ROBOT_H_
#define _ROBOT_H_

#define TAILLE_GRILLE 31
#define NB_SOUS_CASES 40
#define TAILLE_CASE_MM 200

struct Robot{
  int posX;
  int posY;
  int vitesse; //vitesse entre 0 et 15
  int orientation;
};  
typedef struct Robot Robot;

struct Case{
  //int sous_cases[NB_SOUS_CASES/2][NB_SOUS_CASES/2];
  int status;

};
typedef struct Case Case;



#endif