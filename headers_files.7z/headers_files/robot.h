#define Taille_grille 31

struct Robot{
  int posX;
  int posY;
  int vitesse; //vitesse entre 0 et 15
  int orientation;
};  