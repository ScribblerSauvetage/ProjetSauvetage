#include "mouvement.h"
#include "robot.h"
#include "vl53l1x.h"

void algo_v1(){
	
}