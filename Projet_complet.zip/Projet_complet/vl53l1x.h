/**
* This is the main Blank Simple C++ Project program file.
*/

#include "i2clib.h"
#include "VL53L1X_register_map.h"

unsigned int getDistance();
void init_VL53L1X(int mode);

char configBlock[] = {
  0x29, 0x02, 0x10, 0x00, 0x28, 0xBC, 0x7A, 0x81, //8
  0x80, 0x07, 0x95, 0x00, 0xED, 0xFF, 0xF7, 0xFD, //16
  0x9E, 0x0E, 0x00, 0x10, 0x01, 0x00, 0x00, 0x00, //24
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x34, 0x00, //32
  0x28, 0x00, 0x0D, 0x0A, 0x00, 0x00, 0x00, 0x00, //40
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x11, //48
  0x02, 0x00, 0x02, 0x08, 0x00, 0x08, 0x10, 0x01, //56
  0x01, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x02, //64
  0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x0B, 0x00, //72
  0x00, 0x02, 0x0A, 0x21, 0x00, 0x00, 0x02, 0x00, //80
  0x00, 0x00, 0x00, 0xC8, 0x00, 0x00, 0x38, 0xFF, //88
  0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x91, 0x0F, //96
  0x00, 0xA5, 0x0D, 0x00, 0x80, 0x00, 0x0C, 0x08, //104
  0xB8, 0x00, 0x00, 0x00, 0x00, 0x0E, 0x10, 0x00, //112
  0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x0F, //120
  0x0D, 0x0E, 0x0E, 0x01, 0x00, 0x02, 0xC7, 0xFF, //128
  0x8B, 0x00, 0x00, 0x00, 0x01, 0x01, 0x40 //129 - 135 (0x81 - 0x87)
};

void softReset()
{
    Tx_i2c(0x52);
    Tx_i2c(0x00);
    Tx_i2c(0x00);
    Tx_i2c(0x00);
    pause(0.001);
    Tx_i2c(0x52);
    Tx_i2c(0x00);
    Tx_i2c(0x00);
    Tx_i2c(0x01);
} 

void startMeasurement(char offset)
{
  offset = 0; //Start at a location within the configBlock array
  char address = 1 + offset; //Start at memory location 0x01, add offset
  char data_write[32];
  char leftToSend = sizeof(configBlock) - offset;
  while (leftToSend > 0)
  {

    data_write[0] = 0; //MSB of register address 
    data_write[1] = address; //LSB of register address 
    
    char toSend = 30; //Max I2C buffer on Arduino is 32, and we need 2 bytes for address
    if (toSend > leftToSend) toSend = leftToSend;
    for(int x = 0; x < toSend; x++)
    {
        data_write[x+2] = configBlock[x+address-1];
    }
    i2c_write(_deviceAddress, data_write, toSend+2); 

    leftToSend -= toSend;
    address += toSend;
  }
}

int begin()
{
  unsigned int modelID = readRegister16(VL53L1_IDENTIFICATION__MODEL_ID);
  if (modelID != 0xEACC){
    print("Lecture du modelID failed\n");
    return (0);
  }
  //if(!softReset()) print("Erreur softReset\n");
  softReset();
  
  //Polls the bit 0 of the FIRMWARE__SYSTEM_STATUS register to see if the firmware is ready
  /*int counter = 0;
  int  Firmware = readRegister16(VL53L1_FIRMWARE__SYSTEM_STATUS);
  print("Firmware = %x\r\n", Firmware);
  while ((Firmware & 0x01) == 0)
  {
    Firmware = readRegister16(VL53L1_FIRMWARE__SYSTEM_STATUS);
    print("Firmware = %4x\r\n", Firmware);
    if (counter++ == 100) 
    {
      print("Firmware timeout\n");
      return (0); //Sensor timed out
    }        
    pause(.1);
  }*/

  //Set I2C to 2.8V mode. In this mode 3.3V I2C is allowed.
  unsigned int result = readRegister16(VL53L1_PAD_I2C_HV__EXTSUP_CONFIG);
  result = (result & 0xFE) | 0x01;
  if(!writeRegister16(VL53L1_PAD_I2C_HV__EXTSUP_CONFIG, result)) print("config mode 2.8V failed\n");
  
  //Gets trim resistors from chip
  unsigned int i;
  for (i = 0; i < 37; i++) {
      char regVal = readRegister(i + 1);
      configBlock[i] = regVal;
      //print("%d %2x \n", i, regVal);
  }
  startMeasurement(0);
  return 1;
  
}

unsigned int getDistance()
{
  return (readRegister16(VL53L1_RESULT__FINAL_CROSSTALK_CORRECTED_RANGE_MM_SD0))+40;
}  

void setDistanceMode(char mode)
{
    char periodA;
    char periodB;
    char phaseHigh;
    char phaseInit;
    
    switch (mode)
    {
        case 0:
          periodA = 0x07;
          periodB = 0x05;
          phaseHigh = 0x38;
          phaseInit = 6;
          break;
        case 1:
          periodA = 0x0B;
          periodB = 0x09;
          phaseHigh = 0x78;
          phaseInit = 10;
          break;
        case 2:
          periodA = 0x0F;
          periodB = 0x0D;
          phaseHigh = 0xB8;
          phaseInit = 14;
          break;
        //If user inputs wrong range, we default to long range
        default:
          periodA = 0x0F;
          periodB = 0x0D;
          phaseHigh = 0xB8;
          phaseInit = 14;
          break;
    }
    //timing
    writeRegister(VL53L1_RANGE_CONFIG__VCSEL_PERIOD_A, periodA);
    writeRegister(VL53L1_RANGE_CONFIG__VCSEL_PERIOD_B , periodB);
    writeRegister(VL53L1_RANGE_CONFIG__VALID_PHASE_HIGH, phaseHigh);
    
    //dynamic
    writeRegister(VL53L1_SD_CONFIG__WOI_SD0 , periodA);
    writeRegister(VL53L1_SD_CONFIG__WOI_SD1, periodB);
    writeRegister(VL53L1_SD_CONFIG__INITIAL_PHASE_SD0, phaseInit);
    writeRegister(VL53L1_SD_CONFIG__INITIAL_PHASE_SD1, phaseInit);
    
}

void init_VL53L1X(int mode)
{
  setDistanceMode(mode);// 1 normalement
  begin();
}  

