#include "robot.h"
void move_to_point_maison(int dx, int dy);
void orientTo(Robot *robot, int angleVoulu);
void turn_right(Robot *robot);
void turn_left(Robot *robot);
void move_1_case(Robot *robot);