/*
  Blank Simple Project.c
  http://learn.parallax.com/propeller-c-tutorials 
*/
#include "s3.h"
#include "simpletext.h"
#include "algo.h"
#include "robot.h"

#define A_VERFIER 0
#define PAS_OBSTACLE 1
#define OBSTACLE 2 

int main()                                    // Main function
{
  s3_setup();
  pause(100);
  print("Setup\n");
  
  int **grille;
  grille=malloc(sizeof(int*)*TAILLE_GRILLE);
  for(int i=0; i<TAILLE_GRILLE; i++) grille[i]=malloc(sizeof(int)*TAILLE_GRILLE);
  print("int grille\n");
  //***********init grille************//
  for(int i=0; i<TAILLE_GRILLE; i++)
  {
    for(int j=0; j<TAILLE_GRILLE; j++)
    {
      grille[i][j] = 0;     
    }
  }
  //*******************************//  
        
  
  
  //simpleterm_reopen(31,30,0,9600);
  print("debut\n");
  init_VL53L1X(1);
  
  Robot robot;
  robot.posX = 15;
  robot.posY = 15;
  robot.orientation = 90;
  scribbler_heading_is_deg(robot.orientation);
  
  //turn_right(&robot);
  //orientTo(&robot, 0);
  detection360deg(&robot,grille);
  //updateGridWithDetection(&robot, grille, distance);
  
  /*********************
  
  robot.posX = 5;
  robot.posY = 5;
  send_pos_robot();  
  *********************/
  for(int i=0; i<TAILLE_GRILLE; i++) free(grille[i]);
  free(grille);
  return 0;
}
