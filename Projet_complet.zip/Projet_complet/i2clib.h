/*
  Blank Simple Project.c
  http://learn.parallax.com/propeller-c-tutorials 
*/
#include "simpletools.h"
#include <math.h>
#include "s3.h"

#define PinSDA 3
#define PinSCL 5
#define _deviceAddress 0x52

typedef unsigned char uchar;

void dly()
{
  ;  
}  

void start_i2c ()
{
  high(PinSDA);
  dly();
  high(PinSCL);
  dly();
  low(PinSDA);
  dly();
  low(PinSCL);
  dly();
}

void stop_i2c ()
{
  low(PinSDA);
  dly();
  high(PinSCL);
  dly();
  high(PinSDA);
  dly();
}

int Tx_i2c(char dat){
  int i;
  for(i = 0 ; i < 8 ; i++){
     (dat & 0x80 ) ? high(PinSDA) : low(PinSDA);
     dat <<=1;
     dly();
     high(PinSCL);
     dly();
     low(PinSCL);
     dly(); 
  }    
  high(PinSDA);
  high(PinSCL);
  dly();
  int ack = !input(PinSDA);
  low(PinSCL);
  return ack;
}  

char Rx_i2c(int ack){
  char dat=0;
  int i;
  high(PinSDA);
  for(i = 0 ; i < 8 ; i++){
    dat <<= 1;
    do{
      high(PinSCL);
      
    }while(input(PinSCL) == 0);
    dly();
    if(input(PinSDA)) dat |=1 ;
    dly();
    low(PinSCL);     
  }    
  ack ? low(PinSDA) : high(PinSDA);
  high(PinSCL);
  dly();
  low(PinSCL);
  high(PinSDA);
  
  return dat;
}

int i2c_write(char devAddr, char* data_write, int nb_char)
{
  start_i2c();
  if(!Tx_i2c(devAddr)){return 0;}// return 0;
  int i;
  for ( i=0; i<nb_char; i++)
  {
    if(!Tx_i2c(data_write[i])) {return 0;}//return 0;
  } 
  stop_i2c();
  return 1;    
}

void i2c_read(char devAddr, char* read_data, int nb_char)
{
  start_i2c();
  int i = Tx_i2c(devAddr|=1);
  for( i=0; i<nb_char-1; i++)
  {
    read_data[i] = Rx_i2c(0);
  }
  read_data[i] = Rx_i2c(1);
  stop_i2c();  
  return; 
}   

unsigned int readRegister16 (unsigned int regaddr)
{
  unsigned int data;
  uchar data_low;
  uchar data_high;
  
  char data_write[2];
  char data_read[2];
  
  data_write[0] = (regaddr >> 8) & 0xFF;
  data_write[1] = regaddr & 0xFF;
  
  int i = i2c_write(0x52, data_write, 2);
  i2c_read(0x52, data_read, 2);
  
  data_high = data_read[0];
  
  data_write[0] = ((regaddr+1) >> 8) & 0xFF;
  data_write[1] = (regaddr+1) & 0xFF;
  
  i = i2c_write(0x52, data_write, 2);
  i2c_read(0x52, data_read, 2);
  
  data_low = data_read[0];
  data = (data_high <<8) | data_low;
  return data;
  
}

unsigned int readRegister(unsigned int registerAddr)
{
  unsigned int data;
  char data_write[2];
  char data_read[2];
  data_write[0] = (registerAddr >> 8) & 0xFF; //MSB of register address 
  data_write[1] = registerAddr & 0xFF; //LSB of register address 
  i2c_write(0x52, data_write, 2); 
  i2c_read(0x52,data_read,2);
  //Read Data from selected register
  data=data_read[0];
  return data;
}

unsigned int writeRegister(unsigned int registerAddr, char data)
{
    char data_write[3];
    data_write[0] = (registerAddr >> 8) & 0xFF; //MSB of register address 
    data_write[1] = registerAddr & 0xFF; //LSB of register address 
    data_write[2] = data & 0xFF; 
    if(!i2c_write(_deviceAddress, data_write, 3)) return 0;
	return 1;
}

unsigned int writeRegister16(unsigned int registerAddr, unsigned int data)
{
    char data_write[3];
    data_write[0] = (registerAddr >> 8) & 0xFF; //MSB of register address 
    data_write[1] = registerAddr & 0xFF; //LSB of register address 
    data_write[2] = (data >> 8) & 0xFF;
    
    if(!i2c_write(_deviceAddress, data_write, 3)) return 0;
    
    data_write[0] = ((registerAddr+1) >> 8) & 0xFF; //MSB of register address 
    data_write[1] = (registerAddr+1) & 0xFF; //LSB of register address 
    data_write[2] = (data) & 0xFF;
    
    if(!i2c_write(_deviceAddress, data_write, 3)) return 0;  
	return 1;
}    
