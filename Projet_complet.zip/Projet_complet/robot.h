#ifndef _ROBOT_H_
#define _ROBOT_H_

#define TAILLE_GRILLE 31

struct Robot{
  int posX;
  int posY;
  int vitesse; //vitesse entre 0 et 15
  int orientation;
};  
typedef struct Robot Robot;

#endif