#include "robot.h"

void algo_v1(Robot *robot,  int **grille);
void  detection360deg(Robot *robot, int **grille);
void updateGridWithDetection(Robot *robot, int **grille, int distance);