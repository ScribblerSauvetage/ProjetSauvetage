#include "mouvement.h"
#include "s3.h"

/*void move_to_point_maison(int dx, int dy){
  int32_t	angle;
  scribbler_turn_to((angle = atan((float)dy/(float)dx)));
  scribbler_go_forward((sqrt(((dx * dx) + (dy * dy))))); 
} */

void orientTo(Robot *robot, int angleVoulu){
  if(angleVoulu==0)angleVoulu=360;     
  int delta = abs(angleVoulu - robot->orientation);
  int angle = 180 - abs(delta - 180); 
  if(delta> 180)angle*=-1;
  scribbler_turn_by_deg(angle);
  scribbler_wait_stop();
  robot->orientation = angleVoulu;
}

// 180 - abs(abs(10 - 90) - 180) = 80 
// 180 - abs(abs(10 - 270) - 180) = 100 

void turn_right(Robot *robot)
{
  scribbler_turn_by_deg(-90);
  scribbler_wait_stop();
  robot->orientation-= 90;
  if(robot->orientation<0) { robot->orientation+= 360; }
  robot->orientation = robot->orientation%360;
  //print("%d \n", robot.orientation);
}

void turn_left(Robot *robot)
{
  scribbler_turn_by_deg(90);
  scribbler_wait_stop();
  robot->orientation+= 90;
  robot->orientation = robot->orientation%360;
  //print("%d \n", robot.orientation);
} 

void move_1_case(Robot *robot) // fais avancer le robot d'une case
{
  scribbler_go_forward(400);
  if(robot->orientation == 90)
    {
      robot->posY-=1;
    }
  else if(robot->orientation == 0)
    {
      robot->posX+=1;
    }
  else if(robot->orientation == 180)
    {
      robot->posX-=1;
    }
  else
    {
      robot->posY+=1;
    }
} 