#include "mouvement.h"
#include "algo.h"
#include "vl53l1x.h"
#define M_PI 3.14159265358979323846f
#include <math.h>

void algo_v1(Robot *robot,  int **grille){
	
}

void  detection360deg(Robot *robot, int **grille){
  int distance;
  const int PAS=5;
  int angle;
  int ori;
  scribbler_set_speed(3);
  for(angle=0;  angle < 360; angle+=PAS){
    //pause(200);
    orientTo(robot, (robot->orientation)+PAS);
    //distance = getDistance();
    ori = robot->orientation;
    print("ori=%d",ori);
    //updateGridWithDetection(robot, grille, distance);
  }
  orientTo(robot, (robot->orientation)+PAS);
  //print("ori=%d\n",0);
}

void updateGridWithDetection(Robot *robot,  int **grille, int distance){
  int x_point=0,y_point=0;
  x_point = cosf(robot->orientation*M_PI/180.f)*distance; // Valeur en millimetre
  y_point = sinf(robot->orientation*M_PI/180.f)*distance;
  
  print("x=%d, y=%d\n",x_point,y_point);
}